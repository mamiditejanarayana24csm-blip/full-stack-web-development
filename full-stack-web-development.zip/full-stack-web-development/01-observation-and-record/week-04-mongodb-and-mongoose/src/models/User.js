const mongoose = require("mongoose");

const userSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    email: { type: String, required: true, unique: true, lowercase: true },
    age: { type: Number, min: 16, max: 100 },
  },
  { timestamps: true }
);

module.exports = mongoose.model("User", userSchema);
